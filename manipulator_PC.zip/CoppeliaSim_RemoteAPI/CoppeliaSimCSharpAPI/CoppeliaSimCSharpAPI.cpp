#include "pch.h"
#include "CoppeliaSimCSharpAPI.h"

COPPELIASIMCSHARPAPI_API int Connect(const char* address, int port) {
    int id = simxStart(address, port, true, true, 2000, 5);
    extApi_sleepMs(300);
    if (IsConnected(id)) {
        SendInfo(id, "[Remote API] Connected", false);
    }
    return id;
}

COPPELIASIMCSHARPAPI_API int Disconnect(int id) {
    extApi_sleepMs(300);
    if (IsConnected(id)) {
        SendInfo(id, "[Remote API] Disconnected", true);
        simxFinish(id);
    }
    return 0;
}

COPPELIASIMCSHARPAPI_API bool IsConnected(int id) {
    bool isConnected = false;
    if (id != -1) {
        if (simxGetConnectionId(id) != -1) {
            isConnected = true;
        }
    }
    return isConnected;
}

COPPELIASIMCSHARPAPI_API int MoveJoint(int id, int jointHandle[], float position[], bool inTorqueForceMode, int jointCount) {
    simxPauseCommunication(id, 1);
    if (inTorqueForceMode) {
        for (int i = 0; i < jointCount; i++) {
            simxSetJointTargetPosition(id, jointHandle[i], TO_RAD(position[i]), simx_opmode_oneshot);
        }
    }
    else {
        for (int i = 0; i < jointCount; i++) {
            simxSetJointPosition(id, jointHandle[i], TO_RAD(position[i]), simx_opmode_oneshot);
        }
    }
    return simxPauseCommunication(id, 0);
}

COPPELIASIMCSHARPAPI_API int GetJointPosition(int id, int jointHandle[], float position[], int jointCount) {
    for (int i = 0; i < jointCount; i++) {
        float pos;
        simxGetJointPosition(id, jointHandle[i], &pos, simx_opmode_blocking);
        position[i] = TO_DEGREE(pos);
    }
    return 0;
}

COPPELIASIMCSHARPAPI_API int GetJointVelocity(int id, int jointHandle, float speed, float omega) { // doesn't work
    float lin_vel, ang_vel;
    simxPauseCommunication(id, 1);
    simxGetObjectVelocity(id, jointHandle, &lin_vel, &ang_vel, simx_opmode_blocking);
    speed = lin_vel;
    omega = ang_vel;
    simxPauseCommunication(id, 0);
    return omega;
}

COPPELIASIMCSHARPAPI_API int GetObjectHandle(int id, const char* objectName) {
    int objectHandle;
    simxGetObjectHandle(id, objectName, &objectHandle, simx_opmode_blocking);
    return objectHandle;
}

COPPELIASIMCSHARPAPI_API int SendInfo(int id, const char* message, bool blocking) {
    return simxAddStatusbarMessage(id, message, blocking ? (simxInt)simx_opmode_blocking : (simxInt)simx_opmode_oneshot);
}

COPPELIASIMCSHARPAPI_API INT_PTR GetForceSensorData(int id, int fsHandle) {
    simxPauseCommunication(id, 1);
    UCHAR state;
    float forceVector[3], torqueVector[3];

    simxReadForceSensor(id, fsHandle, &state, forceVector, torqueVector, simx_opmode_oneshot);

    simxPauseCommunication(id, 0);

    float* data = new float[3];
    memcpy(data, forceVector, sizeof(float) * 3);

    return reinterpret_cast<INT_PTR>(data);
}

COPPELIASIMCSHARPAPI_API int MoveJoint_Velocity(int id, int jointHandle, double velocity) {
    simxPauseCommunication(id, 1);

    simxSetJointTargetVelocity(id, jointHandle, velocity, simx_opmode_oneshot);

    return simxPauseCommunication(id, 0);
}

COPPELIASIMCSHARPAPI_API int StartSimulation(int id) {
    simxStartSimulation(id, simx_opmode_oneshot);
    return 0;
}

COPPELIASIMCSHARPAPI_API int PauseSimulation(int id) {
    simxPauseSimulation(id, simx_opmode_oneshot);
    return 0;
}

COPPELIASIMCSHARPAPI_API int StopSimulation(int id) {
    simxStopSimulation(id, simx_opmode_oneshot);
    return 0;
}

