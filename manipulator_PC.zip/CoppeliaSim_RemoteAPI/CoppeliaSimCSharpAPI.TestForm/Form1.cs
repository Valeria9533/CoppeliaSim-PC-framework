﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using AccurateTimerSpace;

namespace CoppeliaSimCSharpAPI.TestForm
{
    public partial class Form1 : Form
    {
        //------------------------------------------------ VARIABLE DEFINITIONS------------------------------------------------//
        /* robot elements */
        private const string _jointPrefix = "UR5_joint"; // ur5
        private const string Rj1 = "Rj1"; // joints
        private const string Rj11 = "Rj1_1";
        private const string Rj2 = "Rj2";
        private const string Rj21 = "Rj2_1";
        private const string Rj3 = "Rj3";
        private const string Rj31 = "Rj3_1";
        private const string Fs1 = "Fs1";
        private const string Fs2 = "Fs2";
        private const string Fs3 = "Fs3";

        private int _id;
        private int[] _jointHandle = new int[6]; // ur5
        private int[] rj1Handle = new int[1]; // kali
        private int[] rj2Handle = new int[1];
        private int[] rj3Handle = new int[1];
        private int[] rj11Handle = new int[1];
        private int[] rj21Handle = new int[1];
        private int[] rj31Handle = new int[1];
        private int fs1Handle, fs2Handle, fs3Handle;

        /* timer values */
        AccurateTimer timer;
        int delay = 1;   // In milliseconds
        Stopwatch stopwatch = new Stopwatch();
        long time;

        /* user values */
        double prox_speed = 0;
        double err_int = 0, pi_out_min = 0, pi_out_max = 180;
        double beta = 10, beta_des = 0;
        double force1_filt = 0, force2_filt = 0, force3_filt = 0, sum_force = 0, force1, force2, force3;
        double[] F_arr = new double[2];
        double[] X_arr = new double[2];
        int holding_time = 0, i = 0, slip = 0, slip_por = 0;

        short obj_up = 0, z3 = 1, z2 = 1, release = 0, state1 = 0, state2 = 0, state3 = 0, time1 = 0;
        double t = 0;

        double force_desired = 0;

        // init position
        double d1_mov_y = -0.64388, d1_mov_z = 0.89946;
        double d2_mov_y = -0.64388, d2_mov_z = 0.89946;
        double d3_mov_y = -0.55958, d3_mov_z = 0.89946;

        double d1_prox_y = 0, d1_prox_z = 0, d2_prox_y = 0, d2_prox_z = 0, d3_prox_y = 0, d3_prox_z = 0;        

        double d1_dist_y = 0, d1_dist_z = 0, d2_dist_y = 0, d2_dist_z = 0, d3_dist_y = 0, d3_dist_z = 0;
        double d2_prox_y1 = 0, d2_prox_z1 = 0, d3_prox_y1 = 0, d3_prox_z1 = 0;
        double d2_dist_y1 = 0, d2_dist_z1 = 0, d3_dist_y1 = 0, d3_dist_z1 = 0;
        double delta_z2, delta_z3, delta_x;

        // SMC_PD controller parameters
        double m_dist = 0.05, a_dist = 0.01807, b_dist = 0.02465, c_dist = 0.08248;
        double j, w, M_L, M_s, J, J_L, J_pr, M_max;

        float[] result1 = new float[3]; // Создаем массив float с 3 элементами
        float[] result2 = new float[3];
        float[] result3 = new float[3];

        float[] position1 = new float[1];
        float[] position2 = new float[1];
        float[] position3 = new float[1];
        float[] position11 = new float[1];
        float[] position21 = new float[1];
        float[] position31 = new float[1];

        //------------------------------------------------ INTERFACE FUNCTIONS ------------------------------------------------//
        public Form1()
        {
            InitializeComponent();    
            w = 7220 * 0.1;
            M_L = 0.05 * w / j * 0.024;
            M_s = M_L / (j * 0.84);
            j = Math.PI * 0.003 / 0.001;
            J = 5.2 * Math.Pow(10, -8);
            J_L = 1 / 12 * m_dist * (Math.Pow(b_dist, 2) + Math.Pow(c_dist, 2));
            J_pr = J + Math.Pow(i,2) * (J_L + m_dist * Math.Pow((c_dist / 2),2));
            M_max = 0.0141 / (j * 0.84);
            Api.StartSimulation(0);
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            _id = Api.Connect(textBoxAddress.Text, (int)numericUpDownPort.Value);            
            if (Api.IsConnected(_id))
            {
                // UR5
                for (int i = 0; i < _jointHandle.Length; i++)
                {
                    _jointHandle[i] = Api.GetObjectHandle(_id, _jointPrefix + (i + 1));
                }

                // hand
                rj1Handle[0] = Api.GetObjectHandle(_id, Rj1);
                rj11Handle[0] = Api.GetObjectHandle(_id, Rj11);
                rj2Handle[0] = Api.GetObjectHandle(_id, Rj2);
                rj21Handle[0] = Api.GetObjectHandle(_id, Rj21);
                rj3Handle[0] = Api.GetObjectHandle(_id, Rj3);
                rj31Handle[0] = Api.GetObjectHandle(_id, Rj31);

                // force sensors
                fs1Handle = Api.GetObjectHandle(_id, Fs1);
                fs2Handle = Api.GetObjectHandle(_id, Fs2);
                fs3Handle = Api.GetObjectHandle(_id, Fs3);               
            }
            timer1.Enabled = true;
            timer = new AccurateTimer(this, new Action(timerCall), delay);           
        }

        private void buttonDisconnect_Click(object sender, EventArgs e)
        {
            Api.Disconnect(_id);
            backgroundWorker1.CancelAsync();
        }

        private void buttonGrasp_Click(object sender, EventArgs e)
        {
            try
            {                             
                prox_speed = 5;
                slip_por = 100;
                release = 0;
                backgroundWorker1.CancelAsync();
                if (!backgroundWorker1.IsBusy) backgroundWorker1.RunWorkerAsync();
            }
            catch { }
        }

        private void buttonRelease_Click(object sender, EventArgs e)
        {
            release = 1; state1 = 0; state2 = 0; state3 = 1; 
            obj_up = 0;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try {               
                buttonDisconnect.PerformClick();
                buttonStop.PerformClick();
            }
            catch (Exception) {}
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            t++;

            chart1.Series[0].Points.AddXY(t / 100, sum_force); // force, N
            chart2.Series[0].Points.AddXY(t / 100, delta_x * 100); // deform, mm

            if (chart1.Series[0].Points.Count > 600) chart1.Series[0].Points.RemoveAt(0);
            if (chart2.Series[0].Points.Count > 600) chart2.Series[0].Points.RemoveAt(0);

            chart1.ChartAreas[0].RecalculateAxesScale();
            chart2.ChartAreas[0].RecalculateAxesScale();

            if (obj_up == 0) textBox5.Text = Convert.ToString(Math.Round(force_desired*1000)/1000);
        }

        private void buttonPause_Click(object sender, EventArgs e)
        {
            Api.PauseSimulation(_id);
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            Api.StopSimulation(_id);
        }

        //------------------------------------------------ USER FUNCTIONS------------------------------------------------------//
        public void timerCall()
        {
            time1 = 1;

            textBox2.Text = Convert.ToString(Math.Round(force1_filt * 1000) / 1000);
            textBox1.Text = Convert.ToString(Math.Round(force2_filt * 1000) / 1000);
            textBox3.Text = Convert.ToString(Math.Round(force3_filt * 1000) / 1000);
            textBox4.Text = Convert.ToString(Math.Round(sum_force * 1000) / 1000);

            if (state1 == 1) // reaching
            {
                label12.BackColor = Color.LimeGreen;
                label13.BackColor = Color.White;
                label11.BackColor = Color.White;
            }
            else if (state2 == 1) // holding
            {
                label12.BackColor = Color.White;
                label13.BackColor = Color.White;
                label11.BackColor = Color.LimeGreen;
            }
            else if (state3 == 1) // releasing
            {
                label12.BackColor = Color.White;
                label11.BackColor = Color.White;
                label13.BackColor = Color.LimeGreen;
            }
        }

        public double PI_controller(double desired, double actual, double Kp, double Ki)
        {
            double err_curr = 0, _out = 0;

            err_curr = desired - actual;
            err_int = err_int + Ki * err_curr;

            if (Ki == 0) err_int = 0;

            if (err_int < pi_out_min) err_int = pi_out_min;
            else if (err_int > pi_out_max) err_int = pi_out_max;
  
	        _out = Kp * err_curr + err_int;

            if (_out < pi_out_min) _out = pi_out_min;
            else if(_out > pi_out_max) _out = pi_out_max;

            return _out;
        }

        public void motor_control(int[] joint_handle, double force_desired, double force_filt)
        {
            double force_des, force_act, force_err, force_err_div, h, u;
            float omega_act;
            var pos_act = new float[1];

            force_des = force_desired; // force desired
            force_act = force_filt; // pos actual

            Api.GetJointPosition(_id, joint_handle, pos_act, 1);
            omega_act = pos_act[0] / time;
            force_err = force_des - force_act;
            force_err_div = -omega_act;
            
            h = force_err + 0.5 * J_pr / M_max * force_err_div * Math.Abs(force_err_div);

            if (h > beta) u = 1;
            else if (h < -beta) u = -1;
            else u = h / beta;

            Api.MoveJoint_Velocity(_id, joint_handle[0], u * force_desired);
        }

        public void UR5_up()
        {
            var position = new float[] { (float)numericUpDownJ1.Value, (float)numericUpDownJ2.Value, (float)numericUpDownJ3.Value,
            -(float)numericUpDownJ4.Value, (float)numericUpDownJ5.Value, (float)numericUpDownJ6.Value };
  
            Api.MoveJoint(_id, _jointHandle, position, true, _jointHandle.Length);
            Api.MoveJoint(_id, _jointHandle, position, true, _jointHandle.Length);
        }

        public void hand_control()
        {
            stopwatch.Restart();

            /* control joints */
            // go slowly (speed control)
            if (force1_filt <= 0.001)
            {
                Api.MoveJoint_Velocity(_id, rj1Handle[0], prox_speed * Math.PI / 180);
                Api.MoveJoint_Velocity(_id, rj11Handle[0], 0);
                state1 = 1; state2 = 0; state3 = 0;
            }
            else
            { // switch on force controller
                Api.MoveJoint_Velocity(_id, rj1Handle[0], 0);
                motor_control(rj11Handle, force_desired / 4, force1_filt);
                state1 = 0; state2 = 1; state3 = 0;
            }

            if (force2_filt <= 0.001)
            {
                Api.MoveJoint_Velocity(_id, rj2Handle[0], prox_speed * Math.PI / 180);
                Api.MoveJoint_Velocity(_id, rj21Handle[0], 0);
                state1 = 1; state2 = 0; state3 = 0;
            }
            else
            {
                Api.MoveJoint_Velocity(_id, rj2Handle[0], 0);
                motor_control(rj21Handle, force_desired / 4, force2_filt);
                state1 = 0; state2 = 1; state3 = 0;
            }

            if (force3_filt <= 0.001)
            {
                Api.MoveJoint_Velocity(_id, rj3Handle[0], prox_speed * Math.PI / 180);
                Api.MoveJoint_Velocity(_id, rj31Handle[0], 0);
                state1 = 1; state2 = 0; state3 = 0;
            }
            else
            {
                Api.MoveJoint_Velocity(_id, rj3Handle[0], 0);
                motor_control(rj31Handle, force_desired / 2, force3_filt);
                state1 = 0; state2 = 1; state3 = 0;
            }

            stopwatch.Stop();
            time = stopwatch.ElapsedMilliseconds;
        }

        //---------------------------------------------------- MAIN CYCLE------------------------------------------------------//
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                if (time1 == 1)
                {
                    /* get force data */
                    IntPtr forcePtr1 = Api.GetForceSensorData(_id, fs1Handle); // Получаем указатель
                    IntPtr forcePtr2 = Api.GetForceSensorData(_id, fs2Handle);
                    IntPtr forcePtr3 = Api.GetForceSensorData(_id, fs3Handle);

                    if (forcePtr1 != IntPtr.Zero) Marshal.Copy(forcePtr1, result1, 0, 3); // Копируем данные из указателя в массив result
                    if (forcePtr2 != IntPtr.Zero) Marshal.Copy(forcePtr2, result2, 0, 3);
                    if (forcePtr3 != IntPtr.Zero) Marshal.Copy(forcePtr3, result3, 0, 3);

                    Api.GetJointPosition(_id, rj1Handle, position1, rj1Handle.Length);
                    Api.GetJointPosition(_id, rj2Handle, position2, rj2Handle.Length);
                    Api.GetJointPosition(_id, rj3Handle, position3, rj3Handle.Length);
                    Api.GetJointPosition(_id, rj11Handle, position11, rj11Handle.Length);
                    Api.GetJointPosition(_id, rj21Handle, position21, rj21Handle.Length);
                    Api.GetJointPosition(_id, rj31Handle, position31, rj31Handle.Length);

                    // calculate forces
                    force1 = Math.Sqrt(result1[0] * result1[0] + result1[1] *
                        Math.Sin(position1[0] + position11[0]) *
                        Math.Sin(position1[0] + position11[0]) *
                        result1[1] + result1[2] * result1[2]) - 0.5;

                    force2 = Math.Sqrt(result2[0] * result2[0] + result2[1] *
                        Math.Sin(position2[0] + position21[0]) *
                        Math.Sin(position2[0] + position21[0]) *
                        result2[1] + result2[2] * result2[2]) - 0.5;

                    force3 = Math.Sqrt(result3[0] * result3[0] + result3[1] *
                        Math.Sin(position3[0] + position31[0] + 50 * Math.PI / 180) *
                        Math.Sin(position3[0] + position31[0] + 50 * Math.PI / 180) *
                        result3[1] + result3[2] * result3[2]) - 0.5;

                    // filter forces using 1 order LPF 
                    force1_filt = force1_filt * 0.9 + force1 * 0.1;
                    force2_filt = force2_filt * 0.9 + force2 * 0.1;
                    force3_filt = force3_filt * 0.9 + force3 * 0.1;

                    if ((force1_filt < 0) || (force1_filt > 600)) force1_filt = 0;
                    if ((force2_filt < 0) || (force2_filt > 600)) force2_filt = 0;
                    if ((force3_filt < 0) || (force3_filt > 600)) force3_filt = 0;

                    // calc sum force
                    sum_force = force1_filt + force2_filt + force3_filt;

                    if (release == 1)
                    {
                        Api.MoveJoint_Velocity(_id, rj1Handle[0], -prox_speed * Math.PI / 180);
                        Api.MoveJoint_Velocity(_id, rj2Handle[0], -prox_speed * Math.PI / 180);
                        Api.MoveJoint_Velocity(_id, rj3Handle[0], -prox_speed * Math.PI / 180);
                    }
                    else
                    {
                        if ((obj_up == 0))
                        {
                            if ((sum_force < 0.001) || (delta_x < 0.001)) hand_control();
                            else
                            {
                                force_desired = sum_force;
                                // holding object on the table        
                                if (Math.Abs(sum_force - force_desired) > 0.05) beta++;
                                else
                                {
                                    holding_time = holding_time + 1;
                                    Api.MoveJoint_Velocity(_id, rj1Handle[0], 0);
                                    Api.MoveJoint_Velocity(_id, rj2Handle[0], 0);
                                    Api.MoveJoint_Velocity(_id, rj3Handle[0], 0);
                                    Api.MoveJoint_Velocity(_id, rj11Handle[0], 0);
                                    Api.MoveJoint_Velocity(_id, rj21Handle[0], 0);
                                    Api.MoveJoint_Velocity(_id, rj31Handle[0], 0);
                                }
                                if (holding_time == 100) { obj_up = 1; UR5_up(); }
                            }
                        }

                        /* get joints position */
                        // proximal position
                        d1_prox_y = d1_mov_y + 0.025 * Math.Sin(position1[0]);
                        d1_prox_z = d1_mov_z + 0.025 * Math.Cos(position1[0]) - 0.1;
                        d2_prox_y = d2_mov_y + 0.025 * Math.Sin(position2[0]);
                        d2_prox_z = d2_mov_z + 0.025 * Math.Cos(position2[0]) - 0.1;
                        d3_prox_y = d3_mov_y + 0.025 * Math.Sin(position3[0] + 50 * Math.PI / 180);
                        d3_prox_z = d3_mov_z + 0.025 * Math.Cos(position3[0] + 50 * Math.PI / 180) - 0.1;

                        // distal position
                        d1_dist_y = d1_prox_y + 0.025 * Math.Sin(position1[0] + position11[0]);
                        d1_dist_z = d1_prox_z + 0.025 * Math.Cos(position1[0] + position11[0]) - 0.1;
                        d2_dist_y = d2_prox_y + 0.025 * Math.Sin(position2[0] + position21[0]);
                        d2_dist_z = d2_prox_z + 0.025 * Math.Cos(position2[0] + position21[0]) - 0.1;
                        d3_dist_y = d3_prox_y + 0.025 * Math.Sin(position3[0] + position31[0] + 50 * Math.PI / 180);
                        d3_dist_z = d3_prox_z + 0.025 * Math.Cos(position3[0] + position31[0] + 50 * Math.PI / 180) - 0.1;

                        // get init position
                        if (force2_filt >= 0.01)
                        {
                            if (z2 == 1)
                            {
                                d2_prox_y1 = d2_mov_y + 0.025 * Math.Sin(position2[0]);
                                d2_prox_z1 = d2_mov_z + 0.025 * Math.Cos(position2[0]) - 0.1;
                                d2_dist_y1 = d2_prox_y + 0.025 * Math.Sin(position2[0] + position21[0]);
                                d2_dist_z1 = d2_prox_z + 0.025 * Math.Cos(position2[0] + position21[0]) - 0.1;
                                z2 = 0;
                            }
                        }
                        if (force3_filt >= 0.01)
                        {
                            if (z3 == 1)
                            {
                                d3_prox_y1 = d3_mov_y + 0.025 * Math.Sin(position3[0]);
                                d3_prox_z1 = d3_mov_z + 0.025 * Math.Cos(position3[0]) - 0.1;
                                d3_dist_y1 = d3_prox_y + 0.025 * Math.Sin(position3[0] + position31[0]);
                                d3_dist_z1 = d3_prox_z + 0.025 * Math.Cos(position3[0] + position31[0]) - 0.1;
                                z3 = 0;
                            }
                        }

                        // calc deformation
                        delta_z2 = Math.Abs(d2_dist_y - d2_dist_y1);
                        delta_z3 = Math.Abs(d3_dist_y - d3_dist_y1);
                        delta_x = delta_z2 + delta_z3 - 0.005;
                        if (sum_force < 0.001) delta_x = 0;

                        // check for object sliding and compression when it is lifted
                        if (obj_up == 1)
                        {                           
                            F_arr[i] = sum_force;
                            X_arr[i] = delta_x;

                            if (i >= 1)
                            {
                                if (Math.Abs(F_arr[i] - F_arr[i - 1]) > 0.1) slip = slip + 1;
                                if ((X_arr[i] - X_arr[i - 1] > 0.001) && (slip == 0))
                                {
                                    force_desired = force_desired * 0.9; // reduce grasp force
                                    hand_control(); 
                                }
                                else
                                {
                                    Api.MoveJoint_Velocity(_id, rj1Handle[0], 0);
                                    Api.MoveJoint_Velocity(_id, rj2Handle[0], 0);
                                    Api.MoveJoint_Velocity(_id, rj3Handle[0], 0);
                                    Api.MoveJoint_Velocity(_id, rj11Handle[0], 0);
                                    Api.MoveJoint_Velocity(_id, rj21Handle[0], 0);
                                    Api.MoveJoint_Velocity(_id, rj31Handle[0], 0);
                                }
                                i = 0;
                            }

                            if (slip >= slip_por)
                            {
                                force_desired = force_desired * 1.1;
                                hand_control();
                                slip = 0;
                            }
                            i++;
                        }
                    }
                    time1 = 0;
                }
            }
        }
    }
}
