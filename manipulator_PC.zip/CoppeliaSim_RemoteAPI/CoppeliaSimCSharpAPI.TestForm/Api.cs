﻿using System;
using System.Runtime.InteropServices;

namespace CoppeliaSimCSharpAPI.TestForm
{
    internal class Api
    {
        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int Connect(string address, int port);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int Disconnect(int id);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern bool IsConnected(int id);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int GetJointPosition(int id, int[] jointHandle, float[] position, int jointCount);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int GetJointVelocity(int id, int jointHandle, float speed, float omega);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int GetObjectHandle(int id, string objectName);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int MoveJoint(int id, int[] jointHandle, float[] position, bool inTorqueForceMode, int jointCount);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int SendInfo(int id, string message, bool blocking);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern IntPtr GetForceSensorData(int id, int fsHandle);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int MoveJoint_Velocity(int id, int jointHandle, double velocity);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int StartSimulation(int id);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int PauseSimulation(int id);

        [DllImport("CoppeliaSimCSharpAPI.dll")]
        public static extern int StopSimulation(int id);
    }
}
